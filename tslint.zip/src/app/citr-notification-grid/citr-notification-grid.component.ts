import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-citr-notification-grid',
  templateUrl: './citr-notification-grid.component.html',
  styleUrls: ['./citr-notification-grid.component.css']
})
export class CitrNotificationGridComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
