import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CitrNotificationGridComponent } from './citr-notification-grid.component';

describe('CitrNotificationGridComponent', () => {
  let component: CitrNotificationGridComponent;
  let fixture: ComponentFixture<CitrNotificationGridComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CitrNotificationGridComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CitrNotificationGridComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
