import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-citr-footer',
  templateUrl: './citr-footer.component.html',
  styleUrls: ['./citr-footer.component.css']
})
export class CitrFooterComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
