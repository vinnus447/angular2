import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CitrFooterComponent } from './citr-footer.component';

describe('CitrFooterComponent', () => {
  let component: CitrFooterComponent;
  let fixture: ComponentFixture<CitrFooterComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CitrFooterComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CitrFooterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
