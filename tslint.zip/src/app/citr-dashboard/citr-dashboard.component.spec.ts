import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CitrDashboardComponent } from './citr-dashboard.component';

describe('CitrDashboardComponent', () => {
  let component: CitrDashboardComponent;
  let fixture: ComponentFixture<CitrDashboardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CitrDashboardComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CitrDashboardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
