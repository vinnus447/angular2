import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { AppStore } from '../model/app-store.model';
import * as CIActions from '../actions/createincident.action';
import { IncidentNotification } from '../model/incidentnotification.model';
import { MemberContact } from '../model/membercontact.model';

@Component({
    selector: 'app-citr-dashboard',
    templateUrl: './citr-dashboard.component.html',
    styleUrls: ['./citr-dashboard.component.css']
})
export class CitrDashboardComponent implements OnInit {

    constructor(private router: Router, private store: Store<AppStore>) { }

    ngOnInit() {
    }

    openTab(evt, tabname, listname) {
        var i, tabcontent, tablinks;
        tabcontent = document.getElementsByClassName("tabcontent");
        for (i = 0; i < tabcontent.length; i++) {
            tabcontent[i].style.display = "none";
        }
        tablinks = document.getElementsByClassName("tablinks");
        for (i = 0; i < tablinks.length; i++) {
            tablinks[i].className = tablinks[i].className.replace(" active", "");
        }
        if (listname == "AgencyListDiv") {
            document.getElementById("AgencyListDiv").style.display = "block";
            document.getElementById("IncidentListDiv").style.display = "none";
        } else {
            document.getElementById("AgencyListDiv").style.display = "none";
            document.getElementById("IncidentListDiv").style.display = "block";
        }
        document.getElementById(tabname).style.display = "block";
        evt.currentTarget.className += " active";
    }

    createNewIncident(validate) {
        if (validate == 'confirmrequest') {
            var confirmrequest = confirm("Are you sure that you want to create new request ?");
            if (confirmrequest) {
                this.router.navigate(['incidentnotification']);
            }
        }
    }


    createIncident() {
        this.store.dispatch(new CIActions.CreateIncidentAction(new AppStore(new IncidentNotification(), new MemberContact)));
        this.router.navigate(['incidentnotification']);

    }

    viewHistory() {
        this.router.navigate(['viewHistory']);
    }

    // login(){
    //     this.router.navigate(['login']);
    //   }

    login(validate) {
        if (validate == 'confirmlogout') {
            var confirmlogout = confirm("Are you sure that you want to logout ?");
            if (confirmlogout) {
                this.router.navigate(['login']);
            }

        }

    }
}
