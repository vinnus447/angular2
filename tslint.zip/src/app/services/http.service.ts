import { Injectable } from '@angular/core';
import { Http, Response } from '@angular/http';
import { Headers, RequestOptions } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import { LoginServiceResponse } from '../model/login-service-response';

@Injectable()
export class HttpService {0000
  public loginServiceResponse:LoginServiceResponse;

  constructor(private http: Http) { 

    this.loginServiceResponse =new LoginServiceResponse(200);
  }

  /**authenticateUser(username :String,password :String): Observable<any> {
    return this.http.get("specify the login service to be given").map(res => {res.json();
    console.log("http login service response",res.json());
    return res.json();
    }).catch((error: any) => {
      return Observable.throw(new Error(error.status));
    });
  }*/
  authenticateUser(loginusername: String, loginpassword: String): Promise<LoginServiceResponse> {
    const url = "http://localhost:8080/ltcareIES/admin/users/api" +"?username=" +loginusername + "&password=" + loginpassword;
    let header = new Headers({ 'Content-Type': 'application/json; charset=UTF-8' });
    header.append('Access-Control-Allow-Origin', '*');
    let options = new RequestOptions({headers: header });
    //let bodyString = JSON.stringify({username: loginusername,password:loginpassword});
    //console.log(bodyStrin
    
    return this.http.post(url,options).toPromise().then(response => {
      console.log(response.status);
     this.loginServiceResponse.status=response.status;
      console.log("login service response:"+this.loginServiceResponse);
      return this.loginServiceResponse;
    }).catch(this.handleError);
    /*return this.http.get(url).toPromise().then(response => {
      const loginServiceResponse: LoginServiceResponse = response.json();
      return loginServiceResponse;
    }).catch(this.handleError);*/

  }


  /*private handleError(error: Response | any) {
    // In a real world app, you might use a remote logging infrastructure
    let errMsg: string;
    if (error instanceof Response) {
        const body = error.json() || '';
        const err = body.error || JSON.stringify(body);
        errMsg = `${error.status} - ${error.statusText || ''} ${err}`;
    } else {
        errMsg = error.message ? error.message : error.toString();
    }
    console.error(errMsg);
    return Observable.throw(errMsg);
  }*/

  private handleError(error: any): Promise<any> {
    return Promise.reject(error.message || error);
  }


}
