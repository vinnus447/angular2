import { Action } from '@ngrx/store';
import { AppStore } from '../model/app-store.model';

export const CREATE_INCIDENT = 'CREATE_INCIDENT';

export class CreateIncidentAction implements Action {
    readonly type = CREATE_INCIDENT;
   constructor(public payload: AppStore) {

   };
}

export type CreateIncidentActions = CreateIncidentAction;