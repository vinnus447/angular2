import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {RouterModule,Routes} from '@angular/router';
import { FormsModule } from '@angular/forms';
import {StoreModule} from '@ngrx/store';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { CollapsibleModule } from 'angular2-collapsible';
import { HttpModule } from '@angular/http';
import { ServiceWorkerModule } from '@angular/service-worker';
import { AppComponent } from './app.component';
import { HttpService } from './services/http.service';
import { environment } from '../environments/environment';
import { CitrHeaderComponent } from './citr-header/citr-header.component';
import { CitrFooterComponent } from './citr-footer/citr-footer.component';
import { CitrUserLoginComponent } from './citr-user-login/citr-user-login.component';
import { CitrDashboardComponent } from './citr-dashboard/citr-dashboard.component';
import { IncidentNotificationComponent } from './create-incident/incident-notification/incident-notification.component';
import { MemberContactInformationComponent } from './create-incident/member-contact-information/member-contact-information.component';
import { AdditionalIncidentDetailComponent } from './create-incident/additional-incident-detail/additional-incident-detail.component';
import { IncidenttypeComponent } from './create-incident/incidenttype/incidenttype.component';
import { ProviderInvolvementComponent } from './create-incident/provider-involvement/provider-involvement.component';
import { FinalizeInitialSaveComponent } from './create-incident/finalize-initial-save/finalize-initial-save.component';
import { CitrViewHistoryComponent } from './citr-view-history/citr-view-history.component';
import { CourtorderInformationComponent } from './create-incident/courtorder-information/courtorder-information.component';
import { StatereviewComponent } from './create-incident/statereview/statereview.component';
import { CitrNotificationGridComponent } from './citr-notification-grid/citr-notification-grid.component';
import {createIncidentReducer} from './reducers/createincident.reducer';
const applicationRoutes:Routes = [
  {
    path:'membercontact',
    component:MemberContactInformationComponent
  },
  {
    path:'dashboard',
    component:CitrDashboardComponent
  },{
    path:'incidentnotification',
    component:IncidentNotificationComponent
  },
  {
    path:'additionalincdetails',
    component:AdditionalIncidentDetailComponent
  },
  {
    path:'incidenttype',
    component:IncidenttypeComponent
  },
  
  {
    path:'finalizeinitialsave',
    component:FinalizeInitialSaveComponent
  },
  {
    path:'providerinvolvement',
    component:ProviderInvolvementComponent
  },
  {
    path:'courtOrderInformation',
    component:CourtorderInformationComponent
  },
  {
    path:'statereview',
    component:StatereviewComponent
  },
  {
    path:'viewHistory',
    component:CitrViewHistoryComponent
  },
  {
    path:'',
    redirectTo: '/login',
    pathMatch: 'full'
  },
  {
    path:'login',
    component:CitrUserLoginComponent
  }
]

@NgModule({
  declarations: [
    AppComponent,
    CitrHeaderComponent,
    CitrFooterComponent,
    CitrUserLoginComponent,
    CitrDashboardComponent,
    IncidentNotificationComponent,
    MemberContactInformationComponent,
    AdditionalIncidentDetailComponent,
    IncidenttypeComponent,
    ProviderInvolvementComponent,
    FinalizeInitialSaveComponent,
    CitrViewHistoryComponent,
    CourtorderInformationComponent,
    StatereviewComponent,
    CitrNotificationGridComponent
  ],
  imports: [RouterModule.forRoot(applicationRoutes),StoreModule.forRoot({ciReducer:createIncidentReducer}),
    BrowserModule,HttpModule,FormsModule,BrowserAnimationsModule,CollapsibleModule,
    ServiceWorkerModule.register('/ngsw-worker.js', { enabled: environment.production })
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
