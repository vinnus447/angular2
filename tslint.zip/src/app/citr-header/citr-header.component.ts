import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-citr-header',
  templateUrl: './citr-header.component.html',
  styleUrls: ['./citr-header.component.css']
})
export class CitrHeaderComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
