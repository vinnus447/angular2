import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
import { HttpService } from '../services/http.service';

@Component({
  selector: 'app-citr-user-login',
  templateUrl: './citr-user-login.component.html',
  styleUrls: ['./citr-user-login.component.css'],
  providers: [HttpService]
})
export class CitrUserLoginComponent implements OnInit {

  constructor(private router: Router,
    private httpService: HttpService) { }

  ngOnInit() {
  }

  logCITRUser(e) {
    e.preventDefault();
    var userName = e.target.elements[1].value;
    var password = e.target.elements[2].value;
    //this.router.navigate(['dashboard']);

    this.httpService.authenticateUser(userName, password).then(response => {
      console.log("response.status"+response.status);
      
      if (response.status === 200) {
        this.router.navigate(['dashboard']);
      } else {
        this.handleError(response);
        
      }

    }).catch(this.handleError);


  }

  private handleError(error:any):Promise<any>{
    alert("Invalid Username or Password \n Please enter correct Credentials.");
    return Promise.reject(error.mesage || error);
  }

  
}
