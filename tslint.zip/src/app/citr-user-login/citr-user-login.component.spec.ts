import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CitrUserLoginComponent } from './citr-user-login.component';

describe('CitrUserLoginComponent', () => {
  let component: CitrUserLoginComponent;
  let fixture: ComponentFixture<CitrUserLoginComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CitrUserLoginComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CitrUserLoginComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
