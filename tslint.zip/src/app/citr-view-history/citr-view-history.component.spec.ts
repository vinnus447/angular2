import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CitrViewHistoryComponent } from './citr-view-history.component';

describe('CitrViewHistoryComponent', () => {
  let component: CitrViewHistoryComponent;
  let fixture: ComponentFixture<CitrViewHistoryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CitrViewHistoryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CitrViewHistoryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
