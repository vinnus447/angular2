import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
@Component({
  selector: 'app-additional-incident-detail',
  templateUrl: './additional-incident-detail.component.html',
  styleUrls: ['./additional-incident-detail.component.css']
})
export class AdditionalIncidentDetailComponent implements OnInit {

  constructor(private router:Router) { }

  ngOnInit() {
  }
  switchScreen(typeofscreen){

    if(typeofscreen=='previous'){
      this.router.navigate(['membercontact']);
    }else{
      this.router.navigate(['incidenttype']);
    }
  }
  createNewIncident(validate){
    if(validate=='confirmrequest'){
        var confirmrequest= confirm("Are you sure that you want to create new request ?");
        if(confirmrequest){
    this.router.navigate(['incidentnotification']);
        }
    }
}

  dashboard(validate){
    if(validate=='confirmdashboard'){
      var confirmdashboard= confirm("Are you sure that you want to go back to the dashboard?");
     
      if(confirmdashboard){
        this.router.navigate(['dashboard']);
      }
      
    }
  }


  login(validate){
    if(validate=='confirmlogout'){
      var confirmlogout= confirm("Are you sure that you want to logout ?");
      if(confirmlogout){
        this.router.navigate(['login']);
      }
     
    }
    
  }
}
