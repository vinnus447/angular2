import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AdditionalIncidentDetailComponent } from './additional-incident-detail.component';

describe('AdditionalIncidentDetailComponent', () => {
  let component: AdditionalIncidentDetailComponent;
  let fixture: ComponentFixture<AdditionalIncidentDetailComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdditionalIncidentDetailComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AdditionalIncidentDetailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
