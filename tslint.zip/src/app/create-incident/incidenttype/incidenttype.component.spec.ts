import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { IncidenttypeComponent } from './incidenttype.component';

describe('IncidenttypeComponent', () => {
  let component: IncidenttypeComponent;
  let fixture: ComponentFixture<IncidenttypeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ IncidenttypeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(IncidenttypeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
