import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { StatereviewComponent } from './statereview.component';

describe('StatereviewComponent', () => {
  let component: StatereviewComponent;
  let fixture: ComponentFixture<StatereviewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ StatereviewComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(StatereviewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
