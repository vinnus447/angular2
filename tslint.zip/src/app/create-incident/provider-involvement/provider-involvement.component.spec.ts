import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProviderInvolvementComponent } from './provider-involvement.component';

describe('ProviderInvolvementComponent', () => {
  let component: ProviderInvolvementComponent;
  let fixture: ComponentFixture<ProviderInvolvementComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProviderInvolvementComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProviderInvolvementComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
