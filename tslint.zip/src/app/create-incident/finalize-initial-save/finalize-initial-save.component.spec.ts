import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FinalizeInitialSaveComponent } from './finalize-initial-save.component';

describe('FinalizeInitialSaveComponent', () => {
  let component: FinalizeInitialSaveComponent;
  let fixture: ComponentFixture<FinalizeInitialSaveComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FinalizeInitialSaveComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FinalizeInitialSaveComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
