import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CourtorderInformationComponent } from './courtorder-information.component';

describe('CourtorderInformationComponent', () => {
  let component: CourtorderInformationComponent;
  let fixture: ComponentFixture<CourtorderInformationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CourtorderInformationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CourtorderInformationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
