import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
import { IncidentNotification } from '../../model/incidentnotification.model';
import { AppStore } from '../../model/app-store.model';
import {Store} from '@ngrx/store';
import {Observable} from 'rxjs/Observable';
import {NgForm} from '@angular/forms';

@Component({
  selector: 'app-incident-notification',
  templateUrl: './incident-notification.component.html',
  styleUrls: ['./incident-notification.component.css']
})
export class IncidentNotificationComponent implements OnInit {

  public incidentnotification:Observable<IncidentNotification>;
  public  appStore:Observable<AppStore>;
  public mem:number;
  constructor(private router:Router,private store:Store<AppStore>) {
   
   this.incidentnotification= this.store.select('incidentNotification');
   console.log(this.incidentnotification);
   }

  ngOnInit() {
  }
  switchScreen(typeofscreen){

    if(typeofscreen=='previous'){
      this.router.navigate(['dashboard']);
    }else{
      this.router.navigate(['membercontact']);
    }
  }

  createNewIncident(validate){
    if(validate=='confirmrequest'){
        var confirmrequest= confirm("Are you sure that you want to create new request ?");
        if(confirmrequest){
    this.router.navigate(['incidentnotification']);
        }
    }
}


  dashboard(validate){
    if(validate=='confirmdashboard'){
      var confirmdashboard= confirm("Are you sure that you want to go back to the dashboard?");
     
      if(confirmdashboard){
        this.router.navigate(['dashboard']);
      }
      
    }
  }


  login(validate){
    if(validate=='confirmlogout'){
      var confirmlogout= confirm("Are you sure that you want to logout ?");
      if(confirmlogout){
        this.router.navigate(['login']);
      }
     
    }
    
  }
}
