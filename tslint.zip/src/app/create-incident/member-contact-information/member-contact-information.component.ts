import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
import {NgForm} from '@angular/forms';
import {Observable} from 'rxjs/Rx';
import {MemberContact} from '../../model/membercontact.model';


@Component({
  selector: 'app-member-contact-information',
  templateUrl: './member-contact-information.component.html',
  styleUrls: ['./member-contact-information.component.css']
})
export class MemberContactInformationComponent implements OnInit {
public membercontactdetails:Observable<MemberContact>;
  constructor(private router:Router) {
    
   }

  ngOnInit() {
  }
  switchScreen(typeofscreen){

    if(typeofscreen=='previous'){
      this.router.navigate(['incidentnotification']);
    }else{
      this.router.navigate(['additionalincdetails']);
    } 
  }

  createNewIncident(validate){
    if(validate=='confirmrequest'){
        var confirmrequest= confirm("Are you sure that you want to create new request ?");
        if(confirmrequest){
    this.router.navigate(['incidentnotification']);
        }
    }
}

  dashboard(validate){
    if(validate=='confirmdashboard'){
      var confirmdashboard= confirm("Are you sure that you want to go back to the dashboard?");
     
      if(confirmdashboard){
        this.router.navigate(['dashboard']);
      }
      
    }
  }


  login(validate){
    if(validate=='confirmlogout'){
      var confirmlogout= confirm("Are you sure that you want to logout ?");
      if(confirmlogout){
        this.router.navigate(['login']);
      }
     
    }
    
  }
}
