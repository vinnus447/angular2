import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MemberContactInformationComponent } from './member-contact-information.component';

describe('MemberContactInformationComponent', () => {
  let component: MemberContactInformationComponent;
  let fixture: ComponentFixture<MemberContactInformationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MemberContactInformationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MemberContactInformationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
