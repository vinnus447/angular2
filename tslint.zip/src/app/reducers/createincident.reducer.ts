import * as CIActions from '../actions/createincident.action'
import {AppStore} from '../model/app-store.model';
import { MemberContact } from '../model/membercontact.model';
import { IncidentNotification } from '../model/incidentnotification.model';
const initialState ={
    appStore:new AppStore(new IncidentNotification(),new MemberContact())

}

export function createIncidentReducer(state, action: CIActions.CreateIncidentActions): AppStore {

    switch(action.type){
        case CIActions.CREATE_INCIDENT:
        return action.payload;
        default:
        return state;
    }

};