export class IncidentNotification {

    public memberid: number = 1234567;
    public vulerablechild: boolean;
    public memberfirstname: string;
    public membermiddleintialname: string;
    public memberlastname: string;
    public suffix: string;
    public gender: boolean;
    public dateofbirth: Date;
    public aliasmemberfirstname: string;
    public aliasmembermiddleintialname: string;
    public aliasmemberlastname: string;
    public aliassuffix: string;

    constructor() { }
}