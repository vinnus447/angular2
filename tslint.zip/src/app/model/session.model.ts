export interface Session {

    id?:string;
    expiryWarning?:Date;
    expiry?:Date;
}