
export class LoginServiceResponse {

    
    
   // public message:String;
    
    constructor(public status:number
    ) { }
}