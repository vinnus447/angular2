export class MemberContact {

    primaryPhoneNumber:number=123456;
    currentLivingArrangement:string;
    entityOneparentFirstName:string;
    entityOneMiddleIntialName:string;
    entityOneLastName:string;
    entityOneSuffix:string;
    entityOnePhoneNumber:number;
    entityTwoMiddleIntialName:string;
    entityTwoLastName:string;
    entityTwoSuffix:string;
    entityTwoPhoneNumber:number;

    constructor(){

        
    }
   
}