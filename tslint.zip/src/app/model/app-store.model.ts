import { Session } from './session.model';
import { MemberContact } from '../model/membercontact.model';
import { IncidentNotification } from '../model/incidentnotification.model';
export class AppStore {
    public incidentNotification:IncidentNotification;
    public memberContact:MemberContact;
    //   memberContact:MemberContact;
    // incidentNotification:IncidentNotification;   
    constructor(incidentNotification:IncidentNotification,memberContact:MemberContact){
        this.incidentNotification=incidentNotification;
        this.memberContact=memberContact;
    }
}